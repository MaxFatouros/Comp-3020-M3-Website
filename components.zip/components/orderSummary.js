
let summary = document.querySelector(".summary");

let div = document.createElement("div");
div.innerHTML = `
    <h1> ${window} </h1>
`

summary.appendChild(div);